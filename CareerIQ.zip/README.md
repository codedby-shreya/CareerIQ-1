
  # Dark-themed AI Landing Page

  This is a code bundle for Dark-themed AI Landing Page. The original project is available at https://www.figma.com/design/anBXLl6UDowP7Jo4NuglmS/Dark-themed-AI-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  