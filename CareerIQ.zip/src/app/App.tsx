import image_cf7256bddd57378e8620cbfaa5c10c88d3176e7e from 'figma:asset/cf7256bddd57378e8620cbfaa5c10c88d3176e7e.png'
import image_a6b7b85488190a1cf1334089962b4b64b3a61485 from 'figma:asset/a6b7b85488190a1cf1334089962b4b64b3a61485.png'
import { useState, useEffect } from 'react';
import { 
  Upload, 
  FileText, 
  Brain, 
  TrendingUp, 
  Target, 
  Layers, 
  CheckCircle, 
  BookOpen, 
  BarChart3, 
  GraduationCap, 
  Users, 
  Search, 
  ArrowRight,
  Sparkles,
  ChevronRight,
  Menu,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import heroImage from 'figma:asset/035e7cd7ba0e2cfcb482e094e785cc04ecbaaf8d.png';
import logoImage from 'figma:asset/58a8aad85ba8556f34dd9e5f3591ef53c8693c67.png';

export default function App() {
  const [activeNav, setActiveNav] = useState('home');
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#05020a] text-white overflow-x-hidden selection:bg-violet-500/30 selection:text-violet-200">
      {/* Background Ambience */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-[#020105] via-[#1a0b2e] to-[#020105]"></div>
        <div className="absolute top-0 left-0 w-full h-[500px] bg-gradient-to-b from-violet-900/10 to-transparent opacity-50"></div>
        <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] bg-violet-600/10 rounded-full blur-[100px] animate-pulse-slow"></div>
        <div className="absolute bottom-[-20%] left-[-10%] w-[600px] h-[600px] bg-pink-600/10 rounded-full blur-[100px] animate-pulse-slow"></div>
        {/* Noise overlay simulation */}
        <div className="absolute inset-0 opacity-[0.03] bg-[url('https://grainy-gradients.vercel.app/noise.svg')] brightness-150 contrast-150 mix-blend-overlay"></div>
      </div>

      <div className="relative z-10 font-sans">
        {/* Navbar */}
        <nav 
          className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
            isScrolled 
              ? 'bg-[#05020a]/80 backdrop-blur-xl border-b border-white/5 py-2' 
              : 'bg-transparent py-4'
          }`}
        >
          <div className="max-w-7xl mx-auto px-6 flex items-center justify-between h-24 md:h-28">
            <div className="flex items-center gap-2">
              <img src={image_cf7256bddd57378e8620cbfaa5c10c88d3176e7e} alt="CareerIQ" className="h-32 object-contain" />
            </div>
            
            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-8">
              {['Home', 'How It Works', 'Features', 'For You'].map((item) => (
                <button
                  key={item}
                  onClick={() => setActiveNav(item.toLowerCase().replace(/\s/g, '-'))}
                  className={`font-medium transition-colors hover:text-white ${ activeNav === item.toLowerCase().replace(/\s/g, '-') ? 'text-violet-400' : 'text-gray-400' } text-[16px]`}
                >
                  {item}
                </button>
              ))}
              <button
                className="group relative px-6 py-2.5 rounded-full overflow-hidden transition-all hover:scale-105"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-violet-600 to-pink-600 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                <div className="absolute inset-0 bg-gradient-to-r from-violet-600 to-pink-600 blur-lg opacity-40 group-hover:opacity-60 transition-opacity"></div>
                <span className="relative z-10 font-semibold text-white flex items-center gap-2">
                  Upload Resume
                  <Upload className="w-4 h-4" />
                </span>
              </button>
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden text-white"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </nav>

        {/* Mobile Menu Overlay */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="fixed inset-0 z-40 bg-black/95 backdrop-blur-xl md:hidden pt-32 px-6"
            >
              <div className="flex flex-col gap-6 text-center">
                {['Home', 'How It Works', 'Features', 'For You'].map((item) => (
                  <button
                    key={item}
                    onClick={() => {
                      setActiveNav(item.toLowerCase().replace(/\s/g, '-'));
                      setMobileMenuOpen(false);
                    }}
                    className="text-2xl font-medium text-gray-300 hover:text-white"
                  >
                    {item}
                  </button>
                ))}
                 <button
                  className="mt-4 px-8 py-4 rounded-full bg-gradient-to-r from-violet-600 to-pink-600 font-bold text-lg shadow-[0_0_20px_rgba(139,92,246,0.5)]"
                >
                  Upload Resume
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Hero Section */}
        <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 px-6 overflow-hidden">
          {/* Radial glow behind hero */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-violet-600/20 rounded-full blur-[120px] pointer-events-none"></div>
          
          <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center relative z-10">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="space-y-8 text-center md:text-left"
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 backdrop-blur-md">
                <Sparkles className="w-4 h-4 text-pink-400" />
                <span className="text-xs md:text-sm font-medium text-pink-200 tracking-wide uppercase">AI-Powered Career Intelligence</span>
              </div>
              
              <h1 className="text-5xl md:text-7xl font-bold leading-[1.1] tracking-tight text-white">
                Career Readiness & <br />
                <span className="text-violet-400">
                  Skill Intelligence
                </span> <br />
                System
              </h1>
              
              <p className="text-lg md:text-xl text-gray-300 leading-relaxed max-w-xl mx-auto md:mx-0 font-light">
                Analyze your resume against job roles using advanced AI. Get a readiness score, identify skill gaps, and clear your path to employment.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <button className="group relative px-8 py-4 rounded-full bg-gradient-to-r from-violet-600 to-pink-600 font-semibold text-white transition-all hover:scale-105 shadow-[0_0_20px_rgba(139,92,246,0.5)] hover:shadow-[0_0_35px_rgba(139,92,246,0.7)]">
                  <span className="flex items-center gap-2 text-[20px] font-bold">
                    Check Career Readiness
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </span>
                </button>
                
              </div>
              
              <div className="pt-6 flex items-center justify-center md:justify-start gap-8 text-sm text-gray-400">
                <div className="flex items-center gap-2">
                  
                  
                </div>
                <div className="flex items-center gap-2">
                  
                  
                </div>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
              className="relative"
            >
              <div className="absolute -inset-4 bg-gradient-to-r from-violet-600 to-pink-600 rounded-[2rem] blur-2xl opacity-30 animate-pulse-slow"></div>
              <div className="relative rounded-[2rem] overflow-hidden border border-white/10 bg-[#13082a]/50 backdrop-blur-sm shadow-2xl">
                <div className="absolute inset-0 bg-gradient-to-tr from-white/5 to-transparent pointer-events-none z-10"></div>
                <img 
                  src={heroImage} 
                  alt="AI Dashboard Interface" 
                  className="w-full h-auto object-cover transform hover:scale-105 transition-transform duration-700"
                />
                
                {/* Floating Badge */}
                <motion.div 
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 1, duration: 0.5 }}
                  className="absolute bottom-6 left-6 right-6 bg-black/60 backdrop-blur-xl border border-white/10 p-4 rounded-xl flex items-center gap-4 shadow-lg z-20"
                >
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(74,222,128,0.4)]">
                    <span className="text-black font-bold text-lg">76%</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-white">Ready for Senior Dev</h3>
                    <div className="h-1.5 w-full bg-gray-700 rounded-full mt-2 overflow-hidden">
                      <div className="h-full w-[92%] bg-gradient-to-r from-green-400 to-emerald-500 rounded-full"></div>
                    </div>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* How It Works */}
        <section className="py-24 relative">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-bold mb-4 text-white">
                How It <span className="text-violet-400">Works</span>
              </h2>
              <p className="text-gray-400 text-lg max-w-2xl mx-auto">
                Transform your resume into actionable career insights in four simple steps.
              </p>
            </div>

            <div className="grid md:grid-cols-4 gap-6">
              {[
                { icon: Upload, title: 'Upload Resume', desc: 'Securely upload your PDF or DOCX resume.' },
                { icon: FileText, title: 'Add Job Role', desc: 'Paste the job description you are targeting.' },
                { icon: Brain, title: 'AI Analysis', desc: 'Our engine maps your skills to the requirements.' },
                { icon: TrendingUp, title: 'Get Insights', desc: 'Receive your score and improvement plan.' },
              ].map((step, idx) => (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  key={idx}
                  className="group relative p-8 rounded-2xl bg-white/[0.03] border border-white/5 hover:border-violet-500/50 hover:bg-white/[0.06] transition-all duration-300 hover:-translate-y-2 backdrop-blur-sm"
                >
                  {/* Step Number */}
                  <div className="absolute top-4 right-4 w-8 h-8 rounded-full bg-gradient-to-r from-violet-500/20 to-pink-500/20 border border-violet-500/30 flex items-center justify-center text-xs font-bold text-violet-300 font-mono">
                    0{idx + 1}
                  </div>
                  
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-violet-900/50 to-purple-900/50 border border-violet-500/30 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-[0_0_15px_rgba(139,92,246,0.2)] group-hover:shadow-[0_0_25px_rgba(139,92,246,0.4)]">
                    <step.icon className="w-7 h-7 text-violet-300 group-hover:text-white transition-colors" />
                  </div>
                  
                  <h3 className="text-xl font-bold mb-3 text-white group-hover:text-violet-200 transition-colors">{step.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed group-hover:text-gray-300 transition-colors">{step.desc}</p>
                  
                  {/* Neon Line at bottom */}
                  <div className="absolute bottom-0 left-6 right-6 h-[1px] bg-gradient-to-r from-transparent via-violet-500/50 to-transparent scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Grid */}
        <section className="py-24 relative bg-[#0a0514]/50">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-violet-900/20 via-[#05020a] to-[#05020a] pointer-events-none"></div>
          
          <div className="max-w-7xl mx-auto px-6 relative z-10">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-5xl font-bold mb-4 text-white">
                Powerful <span className="text-violet-400">Features</span>
              </h2>
              <p className="text-gray-400 text-lg max-w-2xl mx-auto">
                Everything you need to bridge the gap between education and employment.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {[
                {
                  icon: Target,
                  title: 'Career Readiness Score',
                  desc: 'Get an instant, quantifiable score showing how prepared you are for your target role.',
                  color: 'text-violet-400',
                  border: 'group-hover:border-violet-500/50'
                },
                {
                  icon: Layers,
                  title: 'Skill Gap Analysis',
                  desc: 'Identify exactly which technical and soft skills you need to develop for your dream job.',
                  color: 'text-pink-400',
                  border: 'group-hover:border-pink-500/50'
                },
                {
                  icon: CheckCircle,
                  title: 'Matched vs Missing',
                  desc: 'A clear, visual breakdown of your strengths and specific areas for improvement.',
                  color: 'text-cyan-400',
                  border: 'group-hover:border-cyan-500/50'
                },
                {
                  icon: BookOpen,
                  title: 'Learning Recommendations',
                  desc: 'Personalized course and resource suggestions to directly close your skill gaps.',
                  color: 'text-fuchsia-400',
                  border: 'group-hover:border-fuchsia-500/50'
                },
                {
                  icon: BarChart3,
                  title: 'Visual Dashboards',
                  desc: 'Beautiful interactive charts and graphs to track your career progress over time.',
                  color: 'text-amber-400',
                  border: 'group-hover:border-amber-500/50'
                },
                {
                  icon: Brain,
                  title: 'AI-Powered Insights',
                  desc: 'Smart recommendations based on real-time industry trends and your unique profile.',
                  color: 'text-emerald-400',
                  border: 'group-hover:border-emerald-500/50'
                },
              ].map((feature, idx) => (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.05 }}
                  key={idx}
                  className={`group p-8 rounded-2xl bg-[#0e071e] border border-white/5 transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-violet-900/10 ${feature.border}`}
                >
                  <div className={`w-12 h-12 rounded-lg bg-white/5 flex items-center justify-center mb-6 group-hover:bg-white/10 transition-colors ${feature.color}`}>
                    <feature.icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold mb-3 text-white group-hover:text-violet-200">{feature.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">
                    {feature.desc}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Target Users */}
        <section className="py-24">
          <div className="max-w-7xl mx-auto px-6">
            <h2 className="text-3xl md:text-5xl font-bold text-center mb-16 text-white">
              Who Is This <span className="text-violet-400">For?</span>
            </h2>
            <div className="grid md:grid-cols-4 gap-8">
              {[
                { icon: GraduationCap, title: 'Students', desc: 'Prepare for your first job with confidence.' },
                { icon: Users, title: 'Freshers', desc: 'Stand out in competitive job applications.' },
                { icon: Search, title: 'Job Seekers', desc: 'Optimize your profile for ATS and recruiters.' },
                { icon: TrendingUp, title: 'Career Switchers', desc: 'Plan your transition into a new field effectively.' },
              ].map((user, idx) => (
                <div
                  key={idx}
                  className="text-center space-y-4 p-8 rounded-3xl bg-gradient-to-b from-white/[0.05] to-transparent border border-white/5 hover:border-violet-500/30 transition-all hover:bg-white/[0.08]"
                >
                  <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-violet-500/10 to-pink-500/10 border border-white/10 flex items-center justify-center shadow-[0_0_20px_rgba(139,92,246,0.15)] group-hover:shadow-[0_0_30px_rgba(139,92,246,0.3)]">
                    <user.icon className="w-8 h-8 text-violet-300" />
                  </div>
                  <h3 className="text-xl font-bold text-white">{user.title}</h3>
                  <p className="text-gray-400 text-sm">{user.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Banner */}
        <section className="py-20 px-6">
          <div className="max-w-5xl mx-auto relative overflow-hidden rounded-[2.5rem] p-12 text-center border border-violet-500/30 shadow-[0_0_50px_rgba(139,92,246,0.15)]">
            <div className="absolute inset-0 bg-gradient-to-r from-violet-900/60 to-pink-900/60 backdrop-blur-xl"></div>
            {/* Animated mesh gradient background effect */}
            <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_120%,rgba(120,119,198,0.3),rgba(255,255,255,0))]" />
            
            <div className="relative z-10 space-y-8">
              <h2 className="text-4xl md:text-5xl font-bold text-white">
                Ready to Analyze Your Career Readiness?
              </h2>
              <p className="text-xl text-violet-100/80 max-w-2xl mx-auto">
                Join thousands of professionals who have improved their career prospects with our AI-powered insights.
              </p>
              <button className="px-12 py-5 rounded-full bg-white text-violet-900 hover:bg-violet-50 transition-all shadow-[0_0_25px_rgba(255,255,255,0.4)] hover:shadow-[0_0_35px_rgba(255,255,255,0.6)] text-lg font-bold flex items-center gap-3 mx-auto transform hover:scale-105">
                Upload Resume Now
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-white/5 bg-[#020105] relative overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-violet-900/10 rounded-full blur-[100px] pointer-events-none"></div>
          
          <div className="max-w-7xl mx-auto px-6 py-16 relative z-10">
            <div className="flex flex-col md:flex-row items-center md:items-start justify-between gap-12 text-center md:text-left">
              
              <div className="space-y-6 md:max-w-sm">
                <img src={logoImage} alt="CareerIQ" className="h-40 mx-auto md:mx-0 object-contain" />
                <p className="text-gray-400 leading-relaxed">
                  CareerIQ bridges the gap between talent and opportunity using advanced AI skill intelligence.
                </p>
                <div className="flex gap-4 justify-center md:justify-start">
                  {/* Social placeholders */}
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-violet-600 hover:border-violet-500 transition-all cursor-pointer">
                      <div className="w-4 h-4 bg-gray-400 rounded-sm"></div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-12 md:gap-24 text-left">
                <div className="space-y-4">
                  <h4 className="text-white font-bold text-lg">Platform</h4>
                  <ul className="space-y-2 text-gray-400">
                    
                    <li className="hover:text-violet-400 cursor-pointer transition-colors">Features</li>
                    
                    <li className="hover:text-violet-400 cursor-pointer transition-colors">About Us</li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <h4 className="text-white font-bold text-lg">Resources</h4>
                  <ul className="space-y-2 text-gray-400">
                    
                    <li className="hover:text-violet-400 cursor-pointer transition-colors">Career Guide</li>
                    <li className="hover:text-violet-400 cursor-pointer transition-colors">Support</li>
                    <li className="hover:text-violet-400 cursor-pointer transition-colors">Contact</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-gray-500">
              <div className="flex flex-col md:flex-row items-center gap-2">
                <p>© 2026 CareerIQ. All rights reserved.</p>
                <span className="hidden md:block mx-2 text-gray-700">|</span>
                <p>Incubated at IIT Patna</p>
              </div>
              <p className="italic opacity-70">
                Disclaimer: For educational and self-assessment purposes only
              </p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
